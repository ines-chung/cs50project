# Preproposal

## What idea(s) do you have for your final project?

Implementing the game guess who, (in python?), on a website for users to play against a computer program. 
We will find an algorithm by which the program will play the game with the highest possible success rate of beating the player.



## If you plan to collaborate with one or two classmates, what are their names, and who are their section leaders?

Robby Hill, section leader Margaret Tanzosh

## Do you have any questions of your own?


