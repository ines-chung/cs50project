# Proposal

## What will (likely) be the title of your project?

Guess who?

## In just a sentence or two, summarize your project. (E.g., "A website that lets you buy and sell stocks.")

A python-based website where you can play guess who against a computer.

## In a paragraph or more, detail your project. What will your software do? What features will it have? How will it be executed?

User Side: 
The User will be presented with a grid with every person's "card" (in this case each person is a button), and will then be able to choose their 'person' that the computer opponent will try to find. 
The User will be able to login / create an account on which to play, and the score of each game will be stored in a SQL database (as with finance). As well as win-streaks and high scores (of number of questions it takes to win.) The data from each game, such as running time, number of questions by both players, and the winner will be recorded in said database. 

The 'game' itself will be implemented in python. The python application will store in a matrix every available person, the plying 'board' for both players with each row representing a name and each column representing a feature that they may or may not have (e.g. glasses).  
The human player will input the name of their chosen person, and the application will 'choose' their own person at random. 
At each stage in the game, the python program will take as input the human player's choice of one of the possible yes/no questions and return their own question in response.
After every question is asked the respective 'boards' will be updated, placing an 'eliminated' label on the people who have been ruled out by the enquiries. 
The decision method that the program will follow is choosing the question whose outcome is the closest to 50/50, to ensure the maximal elimination of the board. 
The possible questions will include, on top of the names of each person, yes/no questions on features such as hair colour/style, gender, clothing, glasses etc. 



## If planning to combine CS50's final project with another course's final project, with which other course? And which aspect(s) of your proposed project would relate to CS50, and which aspect(s) would relate to the other course?
 TODO, if applicable

## In the world of software, most everything takes longer to implement than you expect. And so it's not uncommon to accomplish less in a fixed amount of time than you hope.

### In a sentence (or list of features), define a GOOD outcome for your final project. I.e., what WILL you accomplish no matter what?

Having a functioning site where either the player or the computer can win and stores/queries the data or each game efficiently.

### In a sentence (or list of features), define a BETTER outcome for your final project. I.e., what do you THINK you can accomplish before the final project's deadline?

Better styling and more user friendly features. 

### In a sentence (or list of features), define a BEST outcome for your final project. I.e., what do you HOPE to accomplish before the final project's deadline?

Allow for greater customisability of users' accounts, and encourage interaction between different users, such as leaderboards, or allowing different players to play against each other. 

### In a paragraph or more, outline your next steps. What new skills will you need to acquire? What topics will you need to research? If working with one or two classmates, who will do what?

The next two/three of days will be focused on establishing the implemetation of the game itself in python (and SQL), before reframing the application in a web-friendly format usign flask. The last step to be taken will be in styling and user-friendliness, using JavaScript and CSS.

I will focus more on the python implementation of the "game playing algorithm", and Robby will be largely focused on the user-side of the application. After the structure of teh web-application is established, we will both work on the stylisation of the site, and implement additional features as time allows.




