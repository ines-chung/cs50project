# Status Report

#### Your name

Ines Chung-Halpern

#### Your section leader's name

Margaret Tanzosh

#### Project title

Guess Who

***

Short answers for the below questions suffice. If you want to alter your plan for your project (and obtain approval for the same), be sure to email your section leader directly!

#### What have you done for your project so far?

Created an exclusively python version on the game, that can be played from the terminal.
We have also cerated the html pages for the website that will hold the game, and have made progress in reconfiguring the python program to be compatible with the webpage.


#### What have you not done for your project yet?

We are now working on putting the logic fromt the pyhon game into an application.py file with flask, so that the game can be played by the user from the template.

We also need to set up the registering and account features, so that the website remembers the user and their previous game statistics such as number of wins, high_score etc.

Finishing touches

#### What problems, if any, have you encountered?

Minor bugs that are eventually resolved, otherwise no significant obstacles.
